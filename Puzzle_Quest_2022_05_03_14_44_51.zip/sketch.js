const max = 250;
let randNum = Math.ceil(Math.random() * max);

kaboom({
  background: [0,randNum,250]
});

scene("home", ()=>{
  const player = add([
    
  ])
})

