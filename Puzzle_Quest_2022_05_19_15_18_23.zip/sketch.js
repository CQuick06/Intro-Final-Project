kaboom({
  background: [0, 0, 0],
  scale: 1,
});

loadSprite("bear", "bear.jfif"),
  loadSprite("background", "background.jfif"),
  loadSprite("puzzlePiece", "puzzle.jfif"),
  loadSprite("portal", "portal.png"),
  loadSprite("enemy", "enemy.png"),
  loadSprite("coin", "coin.png"),
  loadSprite("heart", "heart.png"),
  loadSprite("ground", "ground.jfif");
loadBean();

const levelConfig = {
  width: 16,
  height: 16,
  pos: vec2(16, 32),
  g: () => [
    "grass",
    sprite("ground", { width: 40 }),
    solid(),
    area(),
    origin("bot"),
  ],
  p: () => [
    "piece",
    sprite("puzzlePiece", { width: 30 }),
    solid(),
    area(),
    origin("bot"),
  ],
  $: () => [
    "coin",
    sprite("coin", { width: 20 }),
    area(),
    origin("bot"),
  ],
  e: () => [
    "enemy",
    sprite("enemy", { width: 60 }),
    area(),
    body(),
    origin("bot"),
    {
      xVel:35,
    },
  ],
  b: ()=>[
    "barrier",
    sprite("ground", {width:40}),
    area(),
    opacity(0)
  ]
};

const levels = [
  [
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "       $$$",
    "          ",
    "gggggggggg",
    "          ",
    "                     b            b       ",
    "               $$          e           p ",
    "                      ",
    "               gggggggggggggggggggggggggg",
  ],
  [
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "    $$$$  ",
    "          ",
    "ggggggggg          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "       b          b",
    "      $$     e   $$$       p $$",
    "          ",
    "      ggggggggggggggggggggggggg",
  ],
  [
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "                 $$$ b  $$$ e $$$  b  ",
    "          ",
    "                 ggggggggggggggggggggg",
    "          ",
    "          ",
    "            $$$ ",
    "          ",
    "gggggggggggggggg          ",
    "          ",
    "          ",
    "                     $$$$    p",
    "          ",
    "                    gggggggggg",
  ],
  ["           "
  ],
];

let levelNum = 0;

scene("home", () => {
  add([
    sprite("background", {
      width: width(),
    }),
  ]);

  const player = add([
    sprite("bear", {
      width: 75,
      length: 75,
    }),
    pos(50, 350),
    area({ scale: 0.75 }),
    solid(),
    body(),
    origin("bot"),
    {
      speed: 300,
      jumpHeight: 500,
    },
  ]);

  onKeyDown("left", () => {
    player.move(-player.speed, 0);
    player.flipX(false);
  });
  onKeyDown("right", () => {
    player.move(player.speed, 0);
    player.flipX(true);
  });
  onKeyPress("up", () => {
    player.jump(player.jumpHeight);
  });
  onKeyPress("down", () => {
    player.jump(-player.jumpHeight);
  });

  add([
    sprite("ground", { width: width(), height: height() / 2.5 }),
    origin("bot"),
    area(),
    solid(),
    pos(width() / 2, height()),
  ]);
  add([
    text("Puzzle Quest", {
      size: 60,
      font: "apl386o",
    }),
    pos(width() / 2, 100),
    origin("center"),
  ]);
  add([
    "playButton",
    text("PLAY", {
      size: 50,
      font: "apl386o",
    }),
    pos(width() / 2, 175),
    origin("center"),
    area(),
  ]);
  add([
    "tutorialButton",
    text("Tutorial", {
      size: 30,
      font: "apl386o",
    }),
    pos(width() / 2, 250),
    origin("center"),
    area(),
  ]);
  add([
    "levelSelect",
    text("Select Level", {
      size: 30,
      font: "apl386o",
    }),
    pos(width() / 2, 300),
    origin("center"),
    area(),
  ]);

  onClick("playButton", () => {
    go("game");
  });
});

  let score = 0;

scene("game", () => {
  add([
    sprite("background", {
      width: width(),
      height: height(),
    }),
  ]);

  add([
    sprite("ground", { width: width(), height: height() / 5 }),
    origin("bot"),
    area(),
    solid(),
    pos(width() / 2, height()),
  ]);
  
  let hp = 3;

  const level = addLevel(levels[levelNum], levelConfig);

  let scoreLabel = add([
    text(score, {
      size: 30,
    }),
    pos(width() - 50, 0),
  ]);

  let hpLabel = add([
    text("HP:"+hp, {
      size: 30,
    }),
  ]);

  const player = add([
    sprite("bear", {
      width: 50,
    }),
    solid(),
    pos(50, 0),
    area({ scale: 0.75 }),
    body(),
    origin("bot"),
    {
      speed: 300,
      jumpHeight: 500,
    },
  ]);

  onKeyDown("left", () => {
    player.move(-player.speed, 0);
    player.flipX(false);
  });

  onKeyDown("right", () => {
    player.move(player.speed, 0);
    player.flipX(true);
  });

  onKeyPress("up", () => {
    player.jump(player.jumpHeight);
  });

  onKeyPress("down", () => {
    player.jump(-player.jumpHeight);
  });
  
  onUpdate("enemy", (e) => {
    e.move(e.xVel, 0);
  });
  
  onCollide("enemy", "barrier", (e, b) => {
    e.xVel = -e.xVel;
    if (e.xVel < 0) {
      e.flipX(true);
    } else {
      e.flipX(false);
    }
  });

  player.onCollide("piece", (p) => {
    destroy(p);
    add([
      "portal",
      sprite("portal", { width: 60 }),
      pos(player.pos.x, player.pos.y - player.width),
      origin("bot"),
      area(),
    ]);
  });

  player.onCollide("enemy", () => {
    shake(1);
    hp--;
    hpLabel.text = "HP:" + hp;
    if (hp == 0) {
      destroy(player);
      wait(0.4, ()=>{
        go("lose");
      });
    }
  });

  player.onCollide("coin", ($) => {
    score += 10;
    destroy($), (scoreLabel.text = score);
  });
  player.onCollide("portal", (P) => {
    levelNum++;
    go("game");
  });
  
  if (levelNum==3){
    go("puzzle")
  }
  
});

scene("lose", () => {
  add([
    sprite("background", {
      width: width(),
      height: height(),
    }),
  ]);
  add([text("Game Over"), pos(width() / 2, height() / 2), origin("bot")]);
  add([
    "restartButton",
    text("RESTART"),
    pos(width() / 2, height() / 2 + 100),
    origin("bot"),
    area(),
  ]);

  onClick("restartButton", () => {
    go("home")
  });
});

scene("puzzle", () => {
  
  add([
    sprite("background", {
      width: width(),
      height: height()
    }),
  ]);
  
   add([
    rect(505,355),
    color(0,0,0),
    pos(width()/2,height()/2),
    origin("center")
  ])
  
  add([
    rect(500,350),
    color(50,150,250),
    pos(width()/2,height()/2),
    origin("center")
  ])
  
     add([
    rect(430,330),
    color(0,0,0),
    pos(width()/2,height()/2),
    origin("center")
  ])

   add([
    rect(425,325),
    color(175,175,175),
    pos(width()/2,height()/2),
    origin("center")
  ])
  
  add([
    rect(width(),20),
    pos(0,height()-20),
    color(50,150,50),
    solid(),
    area()
  ])
  add([
    "1",
    rect(50,50),
    pos(0,0),
    area(),
    body()
  ]),
     add([
    "2",
    rect(70,50),
    pos(100,0),
    area(),
    body()
  ]),
     add([
    "3",
    rect(50,70),
    pos(200,0),
    area(),
    body()
  ]);
});

go("home");
