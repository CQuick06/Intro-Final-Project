kaboom({
  background: [0, 0, 0],
  scale: 1,
});

loadSprite("bear", "Bear1.png"),
  loadSprite("background", "background.jfif"),
  loadSprite("puzzlePiece", "puzzlepiece.png"),
  loadSprite("portal", "portal.png"),
  loadSprite("enemy", "Alien1.png"),
  loadSprite("coin", "Coin.png"),
  loadSprite("1","pp1.png"),
  loadSprite("milkHaven","heaven.jpg")
  loadSprite("2","pp2.png"),
  loadSprite("wm1","wrongmilk1.png"),
  loadSprite("wm2","wrongmilk2.png"),
  loadSprite("RM","rm.png"),
  loadSprite("3","pp3.png"),
  loadSprite("4","pp4.png"),
  loadSprite("qm","unknown.png")
  loadSprite("home","Home.png")
  loadSprite("ground", "Ground1.png");


const levelConfig = {
  width: 16,
  height: 16,
  pos: vec2(16, 32),
  g: () => [
    "grass",
    sprite("ground", { width: 25 }),
    solid(),
    area(),
    origin("bot"),
  ],
  p: () => [
    "piece",
    sprite("puzzlePiece", { width: 50 }),
    solid(),
    area(),
    origin("bot"),
  ],
  $: () => [
    "coin",
    sprite("coin", { width: 15 }),
    area(),
    origin("bot"),
  ],
  e: () => [
    "enemy",
    sprite("enemy", { width: 35 }),
    area(),
    body(),
    origin("bot"),
    {
      xVel:35,
    },
  ],
  b: ()=>[
    "barrier",
    sprite("ground", {width:40}),
    area(),
    opacity(0)
  ]
};

const levels = [
  [
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "       $$$",
    "          ",
    "gggggggggg",
    "          ",
    "                     b            b       ",
    "               $$          e           p ",
    "                      ",
    "               gggggggggggggggggggggggggg",
  ],
  [
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "    $$$$  ",
    "          ",
    "ggggggggg          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "       b          b",
    "      $$     e   $$$       p $$",
    "          ",
    "      ggggggggggggggggggggggggg",
  ],
  [
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "                 $$$ b  $$$ e $$$  b  ",
    "          ",
    "                 ggggggggggggggggggggg",
    "          ",
    "          ",
    "            $$$ ",
    "          ",
    "gggggggggggggggg          ",
    "          ",
    "          ",
    "                     $$$$    p",
    "          ",
    "                    gggggggggg",
  ],
  ["           ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "                     $$$                  ",
    "          ",
    "              gggggggggggg                ",
    "                                         p",
    "          ",
    "                                 ggggggggggg",
    "           b        e   b ",
    "          ",
    "gggggggggggggggggggggggggg         ",
    "          ",
    "          ",
    "          ",
    "                                       b     e   b       $$$$ ",
    "          ",
    "                                 ggggggggggggggggggggggggggggg",
    "          ",
  ],
  [
    "          "
  ],
];

let levelNum = 0;
let dragging = null


function drag() {

	let offset = vec2(0)

	return {
	
		id: "drag",
		require: [ "pos", "area", ],
		add() {
			
			this.onClick(() => {
				if (dragging) {
					return
				}
				dragging = this
				offset = mousePos().sub(this.pos)
				readd(this)
			})
		},
		update() {
			if (dragging === this) {
				cursor("move")
				this.pos = mousePos().sub(offset)
			}
		},
	}

}


scene("home", () => {
  add([
    sprite("background", {
      width: width(),
    }),
  ]);

  const player = add([
    sprite("bear", {
      width: 150,
      length: 150,
    }),
    pos(50, 350),
    area({ scale: 0.75 }),
    solid(),
    body(),
    origin("bot"),
    {
      speed: 300,
      jumpHeight: 500,
    },
  ]);

  onKeyDown("left", () => {
    player.move(-player.speed, 0);
    player.flipX(true);
  });
  onKeyDown("right", () => {
    player.move(player.speed, 0);
    player.flipX(false);
  });
  onKeyPress("up", () => {
    player.jump(player.jumpHeight);
  });
  onKeyPress("down", () => {
    player.jump(-player.jumpHeight);
  });

  add([
    sprite("ground", { width: width(), height: height() / 2.5 }),
    origin("bot"),
    area(),
    solid(),
    pos(width() / 2, height()),
  ]);
  add([
    text("Milk Quest", {
      size: 60,
      font: "apl386o",
    }),
    pos(width() / 2, 100),
    origin("center"),
  ]);
  add([
    "playButton",
    text("PLAY", {
      size: 50,
      font: "apl386o",
    }),
    pos(width() / 2, 175),
    origin("center"),
    area(),
    color(0,250,150)
  ]);


  onClick("playButton", () => {
    go("Story");
  });
});

scene("Story",()=>{
  
  add([
    sprite("background",{
      width: width(),
      height:height()
    })
  ])
  add([
    text("You are a father bear and",{
      size:40
    }),
    pos(width()/2,50),
    origin("center")
  ])
   add([
    text("your family has run out of milk",{
      size:40
    }),
    pos(width()/2,75),
    origin("center")
  ])
  add([
    text("Now, you must go get the milk!",{
      size:40
    }),
    pos(width()/2,100),
    origin("center")
  ])
   add([
    text("Collect coins, avoid enemies, and",{
      size:40
    }),
    pos(width()/2,150),
    origin("center")
  ])
   add([
    text("find the puzzle pieces to uncover the right",{
      size:40
    }),
    pos(width()/2,175),
    origin("center")
  ])
   add([
    text("kind of milk you need!",{
      size:40
    }),
    pos(width()/2,200),
    origin("center")
  ])
   add([
    "startButton",
    text("Begin",{
      size:40
    }),
    pos(width()/2,height()-50),
    origin("center"),
     area()
  ])
  onClick("startButton",()=>{
    go("game")
  })

})

  let score = 0;

scene("game", () => {
  add([
    sprite("background", {
      width: width(),
      height: height(),
    }),
  ]);

  add([
    sprite("ground", { width: width(), height: height() / 5 }),
    origin("bot"),
    area(),
    solid(),
    pos(width() / 2, height()),
  ]);
  
  let hp = 3;

  const level = addLevel(levels[levelNum], levelConfig);

  let scoreLabel = add([
    text(score, {
      size: 30,
    }),
    pos(width() - 50, 0),
  ]);

  let hpLabel = add([
    text("HP:"+hp, {
      size: 30,
    }),
  ]);

  const player = add([
    sprite("bear", {
      width: 65,
    }),
    solid(),
    pos(50, 0),
    area({ scale: 0.75 }),
    body(),
    origin("bot"),
    {
      speed: 300,
      jumpHeight: 500,
    },
  ]);

  onKeyDown("left", () => {
    player.move(-player.speed, 0);
    player.flipX(true);
  });

  onKeyDown("right", () => {
    player.move(player.speed, 0);
    player.flipX(false);
  });

  onKeyPress("up", () => {
    player.jump(player.jumpHeight);
  });

  onKeyPress("down", () => {
    player.jump(-player.jumpHeight);
  });
  
  onUpdate("enemy", (e) => {
    e.move(e.xVel, 0);
  });
  
  onCollide("enemy", "barrier", (e, b) => {
    e.xVel = -e.xVel;
    if (e.xVel < 0) {
      e.flipX(true);
    } else {
      e.flipX(false);
    }
  });

  player.onCollide("piece", (p) => {
    destroy(p);
    add([
      "portal",
      sprite("portal", { width: 60 }),
      pos(player.pos.x, player.pos.y - player.width),
      origin("bot"),
      area(),
    ]);
  });

  player.onCollide("enemy", () => {
    shake(1);
    hp--;
    hpLabel.text = "HP:" + hp;
    if (hp == 0) {
      destroy(player);
      wait(0.4, ()=>{
        go("lose");
      });
    }
  });

  player.onCollide("coin", ($) => {
    score += 10;
    destroy($), (scoreLabel.text = score);
  });
  player.onCollide("portal", (P) => {
    levelNum++;
    go("game");
  });
  
  if (levelNum==4){
    go("puzzle")
  }
  
});

scene("lose", () => {
  add([
    sprite("background", {
      width: width(),
      height: height(),
    }),
  ]);
  add([text("Game Over"), pos(width() / 2, height() / 2), origin("bot")]);
  add([
    "restartButton",
    text("RESTART"),
    pos(width() / 2, height() / 2 + 100),
    origin("bot"),
    area(),
    color(0,250,150)
  ]);

  onClick("restartButton", () => {
    go("home")
  });
});

scene("puzzle", () => {
  
  add([
    sprite("background", {
      width: width(),
      height: height()
    }),
  ]);
  
  
  add([
    text("Drag and drop to Solve the Puzzle",{
      font:"apl386",
      size:40
    }),
    pos(width()/2,100),
    origin("bot")
  ]);
  add([
    text("Click the image below that matches the completed puzzle",{
      font:"apl386",
      size:25
    }),
    pos(width()/2,150),
    origin("bot")
  ]);
  
   add([
    rect(505,355),
    color(0,0,0),
    pos(width()/2,height()/2),
    origin("center")
  ])
  
  add([
    rect(500,350),
    color(50,150,250),
    pos(width()/2,height()/2),
    origin("center")
  ])
  
     add([
    rect(430,330),
    color(0,0,0),
    pos(width()/2,height()/2),
    origin("center")
  ])

   add([
    rect(425,325),
    color(175,175,175),
    pos(width()/2,height()/2),
    origin("center")
  ])
  
  
 
     add([
    sprite("2",{
     width:90
   }),
    pos(width()/2,height()/2),
    area(),
    drag(true),
    origin("center")
  ]),

     add([
    sprite("3",{
     width:80
   }),
    pos(width()/2,height()/2),
    area(),
    drag(true),
    origin("center")
  ])
    add([
    sprite("4",{
     width:70
   }),
    pos(width()/2,height()/2),
    area(),
    drag(true),
    origin("center")
  ])
   add([
   sprite("1",{
     width:70
   }),
    pos(width()/2,height()/2),
    area(),
    drag(true),
    origin("center")
  ]),
  
   
     
  add([
     "rMilk",
    sprite("RM",{
     width:70
   }),
    pos(width()/2+100,height()-50),
    area(),
    origin("center")
  ])
   onClick("rMilk", () => {
    go("WIN")
  });
   add([
     "wMilk1",
    sprite("wm1",{
     width:70
   }),
    pos(width()/2,height()-50),
    area(),
    origin("center")
  ])
   onClick("wMilk1",()=>{
     go("youDoneMessedUp")
   })
  
   add([
    "wMilk2", 
    sprite("wm2",{
     width:70
   }),
    pos(width()/2-100,height()-50),
    area(),
    origin("center")
  ]),
     onClick("wMilk1",()=>{
     go("youDoneMessedUp")
   })
   onClick("wMilk2",()=>{
     go("youDoneMessedUp")
   })
  
  onMouseRelease(() => {
	dragging = null
})
  onUpdate(() => cursor("default"))
})
  
scene("youDoneMessedUp",()=>{
  add([
    sprite("background",{
      width:width(),
      height:height()
    }),
  ])
  
  add([
      text("You picked the wrong kind of milk",{
    size:40
  }),
  pos(width()/2,100),
  origin("center")
 ])
  
  add([
      text("Now your kids are sad :(",{
    size:40
  }),
  pos(width()/2,150),
  origin("center")
  ])
    
  add([
    "restartButton",
      text("RESTART to find the right milk",{
    size:40
  }),
  pos(width()/2,height()/2),
  origin("center"),
    color(0,250,150),
    area()
  ])
  onClick("restartButton", () => {
    go("home")
  });
  
  
})

scene("WIN",()=>{
  
  add([
    sprite("background",{
      width: width(),
      height:height()
    })
  ])
  
  add([
    text("You did it! You got the milk!",{
      size:40
    }),
    pos(width()/2,50),
    origin("center")
  ])
  add([
    text("Now you can choose:",{
      size:30
    }),
    pos(width()/2,225),
    origin("center")
  ])
  add([
    text("Go home or escape with the milk >:D",{
      size:30
    }),
    pos(width()/2,275),
    origin("center")
  ])
  add([
     "homeButton",
    sprite("home",{
      width:100
    }),
    pos(width()/2+100,height()/2),
    origin("center"),
    area()
  ]) 
    add([
     "theUnknown",
    sprite("qm",{
      width:80
    }),
    pos(width()/2-100,height()/2),
    origin("center"),
    area()
  ])
  
   onClick("homeButton", () => {
    go("home")
  });
    onClick("theUnknown", () => {
    go("End")
  });

})

scene("End",()=>{
  add([
    sprite("milkHaven",{
      width:width(),
      height:height()
    })
  ])
  add([
    text("Milk Heaven :D",{
      size:50
    }),
    pos(width()/2,50),
    origin("center")
  ])
  add([
    text("The End",{
      size:40
    }),
    pos(width()/2,height()-50),
    origin("center")
  ])
})

go("home");








