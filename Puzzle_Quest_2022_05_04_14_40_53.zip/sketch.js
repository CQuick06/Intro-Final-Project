const max = 250;
let randNum = Math.ceil(Math.random() * max);
let playerSpeed=200


kaboom({
  background: [0,randNum,250]
});

loadSprite("bear","bear.jfif")

const levelConfig = {
  width: 16,
  height: 16,
  pos: vec2(32, 32),
  //g : ()=>["grass", solid(), area()]
};

const levels = [
];


scene("home", ()=> {
  const player = add([
    rect(50,50),
    pos(50,350)
  ])
  
  onKeyDown("left", ()=>{
    player.move(-playerSpeed,0)
  })
  
    onKeyDown("right", ()=>{
    player.move(playerSpeed,0)
  })
   /*onKeyPress("up", ()=>{
    player.jump
  })*/
  
  add([
    rect(width(),height()-400),
    pos(0,400),
    color (75,250,50)
  ])
  add([
    text("Puzzle Quest",{
      size:60,
    }),
    pos(width()/2,100),
    origin("center")
  ])
  add([
    "playButton",
    text("PLAY",{
      size:50
    }),
    pos(width()/2,175),
    origin("center")
  ])
})

go("home")

