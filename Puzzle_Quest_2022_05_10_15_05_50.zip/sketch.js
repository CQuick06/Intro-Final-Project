const max = 250;
let randNum = Math.ceil(Math.random() * max);

kaboom({
  background: [0, randNum, 250],
  scale: 1,
});

loadSprite("bear", "bear.jfif"),
  loadSprite("background", "background.jfif"),
  loadSprite("puzzlePiece", "puzzle.jfif"),
  loadSprite("portal", "portal.png"),
  loadSprite("ground", "ground.jfif");
loadBean();

const levelConfig = {
  width: 16,
  height: 16,
  pos: vec2(16, 32),
  g: () => [
    "grass",
    sprite("ground", { width: 40 }),
    solid(),
    area(),
    origin("bot"),
  ],
  p: () => [
    "piece",
    sprite("puzzlePiece", { width: 30 }),
    solid(),
    area(),
    origin("bot"),
  ],
};

const levels = [
  [
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "          ",
    "gggggggggg",
    "          ",
    "          ",
    "                   p     d",
    "                      ",
    "               gggggggggg",
  ],
  [
    "          ",
    "          ",
  ],
];

let levelNum = 0;

scene("home", () => {
  add([
    sprite("background", {
      width: width(),
    }),
  ]);

  const player = add([
    sprite("bear", {
      width: 75,
      length: 75,
    }),
    pos(50, 350),
    area({ scale: 0.75 }),
    solid(),
    body(),
    origin("bot"),
    {
      speed: 200,
      jumpHeight: 500,
    },
  ]);

  onKeyDown("left", () => {
    player.move(-player.speed, 0);
    player.flipX(false);
  });

  onKeyDown("right", () => {
    player.move(player.speed, 0);
    player.flipX(true);
  });
  onKeyPress("up", () => {
    player.jump(player.jumpHeight);
  });

  onKeyPress("down", () => {
    player.jump(-player.jumpHeight);
  });

  add([
    sprite("ground", { width: width(), height: height() / 2.5 }),
    origin("bot"),
    area(),
    solid(),
    pos(width() / 2, height()),
  ]);
  add([
    text("Puzzle Quest", {
      size: 60,
      font: "apl386o",
    }),
    pos(width() / 2, 100),
    origin("center"),
  ]);
  add([
    "playButton",
    text("PLAY", {
      size: 50,
      font: "apl386o",
    }),
    pos(width() / 2, 175),
    origin("center"),
    area(),
  ]);
  add([
    "tutorialButton",
    text("Tutorial", {
      size: 30,
      font: "apl386o",
    }),
    pos(width() / 2, 250),
    origin("center"),
    area(),
  ]);
  add([
    "levelSelect",
    text("Select Level", {
      size: 30,
      font: "apl386o",
    }),
    pos(width() / 2, 300),
    origin("center"),
    area(),
  ]);

  onClick("playButton", () => {
    go("game");
  });
});

scene("game", () => {
  add([
    sprite("background", {
      width: width(),
      height: height(),
    }),
  ]);

  add([
    sprite("ground", { width: width(), height: height() / 5 }),
    origin("bot"),
    area(),
    solid(),
    pos(width() / 2, height()),
  ]);

  const level = addLevel(levels[levelNum], levelConfig);

  const player = add([
    sprite("bear", {
      width: 50,
      length: 50,
    }),
    pos(50, 0),
    area({ scale: 0.75 }),
    solid(),
    body(),
    origin("bot"),
    {
      speed: 200,
      jumpHeight: 500,
    },
  ]);

  onKeyDown("left", () => {
    player.move(-player.speed, 0);
  });

  onKeyDown("right", () => {
    player.move(player.speed, 0);
  });
  onKeyPress("up", () => {
    player.jump(player.jumpHeight);
  });

  onKeyPress("down", () => {
    player.jump(-player.jumpHeight);
  });

  player.onCollide("piece", (p) => {
    destroy(p);
    add([
      "portal",
      sprite("portal",{width:60}),
      pos(player.pos.x,player.pos.y-player.width),
      origin("bot"),
      area()
    ])
  });
  
  player.onCollide("portal",(P)=>{
    levelNum++
    go("game")
  })
  
});

go("home");
